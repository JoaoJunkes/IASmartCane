import testeChamadaArquivo

testeChamadaArquivo.PrimeiraExecucao()