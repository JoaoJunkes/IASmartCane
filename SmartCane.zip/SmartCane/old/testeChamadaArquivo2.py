# -*- coding: utf-8 -*-
"""
Created on Tue Aug 14 03:07:12 2018

@author: Joao Junkes
"""

import TesteChamadaArquivo

TesteChamadaArquivo.PrimeiraExecucao()