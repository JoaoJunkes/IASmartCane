# -*- coding: utf-8 -*-
"""
Created on Sat Aug 18 02:16:52 2018

@author: Joao Junkes
"""

import pygame

def Reproduzir(Alerta):
    
    mp3 = str(Alerta)+".mp3"
    
    pygame.init()
    pygame.mixer.music.load(mp3)
    pygame.mixer.music.play()